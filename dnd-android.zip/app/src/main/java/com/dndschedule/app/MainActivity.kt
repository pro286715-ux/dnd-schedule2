package com.dndschedule.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView

class MainActivity : Activity() {
    private lateinit var w: WebView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        w = WebView(this)
        setContentView(w)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.addJavascriptInterface(Bridge(), "Android")
        w.loadUrl("file:///android_asset/index.html")
    }

    override fun onResume() {
        super.onResume()
        Sched.apply(this); Sched.schedule(this)
        if (::w.isInitialized) w.evaluateJavascript("window.refreshAccess&&refreshAccess()", null)
    }

    inner class Bridge {
        @JavascriptInterface fun load(): String = Sched.p(this@MainActivity).getString("data", "") ?: ""
        @JavascriptInterface fun save(json: String) {
            Sched.p(this@MainActivity).edit().putString("data", json).apply()
            Sched.apply(this@MainActivity); Sched.schedule(this@MainActivity)
        }
        @JavascriptInterface fun hasAccess(): Boolean =
            getSystemService(android.app.NotificationManager::class.java).isNotificationPolicyAccessGranted
        @JavascriptInterface fun requestAccess() {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
    }
}
