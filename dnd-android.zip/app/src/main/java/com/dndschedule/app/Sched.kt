package com.dndschedule.app

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONObject
import java.util.Calendar

class Receiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Sched.apply(c); Sched.schedule(c) }
}

object Sched {
    fun p(c: Context) = c.getSharedPreferences("dnd", 0)
    private fun mins(s: String): Int { val a = s.split(":"); return a[0].toInt() * 60 + a[1].toInt() }

    // индекс 0 = «Каждый день», 1..7 = Пн..Вс; хранит только включённые блоки [from, to] в минутах
    fun parse(js: String?): List<List<IntArray>> {
        val out = List(8) { mutableListOf<IntArray>() }
        if (js.isNullOrEmpty()) return out
        val o = JSONObject(js)
        if (!o.optBoolean("master", true)) return out
        val d = o.getJSONArray("days")
        for (i in 0 until minOf(8, d.length())) {
            val l = d.getJSONArray(i)
            for (j in 0 until l.length()) {
                val b = l.getJSONObject(j)
                if (b.optBoolean("on", true)) out[i].add(intArrayOf(mins(b.getString("f")), mins(b.getString("t"))))
            }
        }
        return out
    }

    private fun dow(c: Calendar) = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7 + 1

    fun active(s: List<List<IntArray>>, c: Calendar): Boolean {
        val m = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        val d = dow(c); val y = if (d == 1) 7 else d - 1
        for (i in listOf(0, d)) for (b in s[i]) {
            if (b[0] < b[1]) { if (m >= b[0] && m < b[1]) return true } else if (m >= b[0]) return true
        }
        for (i in listOf(0, y)) for (b in s[i]) if (b[1] <= b[0] && m < b[1]) return true
        return false
    }

    fun apply(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) return
        val want = active(parse(p(c).getString("data", null)), Calendar.getInstance())
        if (want != p(c).getBoolean("applied", false)) {
            nm.setInterruptionFilter(
                if (want) NotificationManager.INTERRUPTION_FILTER_PRIORITY
                else NotificationManager.INTERRUPTION_FILTER_ALL)
            p(c).edit().putBoolean("applied", want).apply()
        }
    }

    fun schedule(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(c, 0, Intent(c, Receiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        am.cancel(pi)
        val s = parse(p(c).getString("data", null))
        val cal = Calendar.getInstance().apply { set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        val cur = active(s, cal)
        for (k in 1..10080) {
            cal.add(Calendar.MINUTE, 1)
            if (active(s, cal) != cur) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi); return
            }
        }
    }
}
